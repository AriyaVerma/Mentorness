
-- Q10. The total number of case of confirmed, deaths, recovered each month

SELECT MONTH(Date) AS EACH_MONTHS_CASE,
count(Confirmed) as Confirmed_Case,
count(Deaths)as Deaths_Case,
COUNT(Recovered) as Recovered_Case
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
    month(Date);

