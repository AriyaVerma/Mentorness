

-- Q16. Find top 5 countries having highest recovered case

SELECT TOP 5
    Country_Region,
    SUM(Recovered) AS total_recovered_cases
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
    Country_Region
ORDER BY 
    total_recovered_cases DESC;