
-- Q9. Find maximum values of confirmed, deaths, recovered per year


    SELECT 
    YEAR(Date) AS year,
    MAX(Confirmed) AS MAX_confirmed,
    MAX(Deaths) AS MAX_deaths,
    MAX(Recovered) AS MAX_recovered
  FROM 
    analysis.dbo.[Corona Virus Dataset]
  GROUP BY 
    YEAR(Date);
