
-- Q14. Find Country having highest number of the Confirmed case
 
 SELECT distinct(Country_Region),MAX(Confirmed) as max_values from analysis.dbo.[Corona Virus Dataset]
 group by Country_Region;