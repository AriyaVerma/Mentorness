
-- Q8. Find minimum values for confirmed, deaths, recovered per year
 
 SELECT 
    YEAR(Date) AS year,
    MIN(Confirmed) AS min_confirmed,
    MIN(Deaths) AS min_deaths,
    MIN(Recovered) AS min_recovered
FROM 
    analysis.dbo.[Corona Virus Dataset]
GROUP BY 
    YEAR(Date);
