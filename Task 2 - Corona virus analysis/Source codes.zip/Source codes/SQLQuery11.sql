

-- Q11. Check how corona virus spread out with respect to confirmed case
--      (Eg.: total confirmed cases, their average, variance & STDEV )

SELECT 
    SUM(Confirmed) AS total_confirmed_cases,
    AVG(Confirmed) AS average_confirmed_cases,
    VAR(Confirmed) AS variance_confirmed_cases,
    STDEV(Confirmed) AS stdev_confirmed_cases
FROM 
    analysis.dbo.[Corona Virus Dataset];
