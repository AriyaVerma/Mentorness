
-- Q3. check total number of rows

SELECT COUNT(*) AS Total_rows FROM analysis.dbo.[Corona Virus Dataset];